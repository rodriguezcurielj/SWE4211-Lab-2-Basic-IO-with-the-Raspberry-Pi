//! SWE4211 Lab 2 Part 3 -- Rust LED blinker.
//!
//! This is the Rust counterpart to the C++ Lab2Part2 program. Like that
//! program, it relies on the POSIX real-time extensions and therefore must be
//! run as the super user (or with CAP_SYS_NICE granted to the binary).
//!
//! Three things separate this version from a naive `thread::sleep` loop:
//!   1. The thread is promoted to SCHED_FIFO at maximum priority, so the
//!      general purpose scheduler cannot preempt it in favor of ordinary work.
//!   2. The address space is locked into RAM, so no page fault can stall a
//!      transition.
//!   3. Sleeps are taken against absolute deadlines on CLOCK_MONOTONIC, so
//!      wake-up latency does not accumulate into the period.

use rppal::gpio::{Gpio, OutputPin};
use std::io::Write;
use std::{env, process};

/// Nanoseconds in one second.
const NSEC_PER_SEC: i64 = 1_000_000_000;

/// prctl option for setting the timer slack. Not re-exported by every libc
/// version, so it is defined locally.
const PR_SET_TIMERSLACK: libc::c_int = 29;

/// Optionally pin the blink thread to a single core. Confining the thread
/// removes migration cost and cross-core cache effects, at the price of taking
/// a core largely out of circulation. `None` leaves the thread schedulable on
/// any CPU.
const PIN_TO_CPU: Option<usize> = None;

/// Reads the monotonic clock.
#[inline]
fn now_monotonic() -> libc::timespec {
    let mut ts: libc::timespec = unsafe { std::mem::zeroed() };
    unsafe {
        libc::clock_gettime(libc::CLOCK_MONOTONIC, &mut ts);
    }
    ts
}

/// Advances a timespec by a number of microseconds, normalizing the result.
#[inline]
fn add_micros(ts: &mut libc::timespec, micros: i64) {
    let mut sec = ts.tv_sec as i64;
    let mut nsec = ts.tv_nsec as i64 + micros * 1_000;

    while nsec >= NSEC_PER_SEC {
        nsec -= NSEC_PER_SEC;
        sec += 1;
    }

    ts.tv_sec = sec as libc::time_t;
    ts.tv_nsec = nsec as _;
}

/// Sleeps until an absolute point on the monotonic clock, restarting the sleep
/// if a signal interrupts it. Because the deadline is absolute, the time spent
/// writing the GPIO and the wake-up latency of the previous cycle are absorbed
/// rather than added to the period.
#[inline]
fn sleep_until(deadline: &libc::timespec) {
    loop {
        let rc = unsafe {
            libc::clock_nanosleep(
                libc::CLOCK_MONOTONIC,
                libc::TIMER_ABSTIME,
                deadline,
                std::ptr::null_mut(),
            )
        };

        // clock_nanosleep returns the error number directly rather than
        // setting errno. Anything other than an interrupting signal means the
        // deadline has passed or cannot be waited on.
        if rc != libc::EINTR {
            break;
        }
    }
}

/// Promotes the calling thread to the highest priority SCHED_FIFO thread.
fn set_realtime_priority() -> std::io::Result<()> {
    unsafe {
        let mut param: libc::sched_param = std::mem::zeroed();
        param.sched_priority = libc::sched_get_priority_max(libc::SCHED_FIFO);

        if libc::sched_setscheduler(0, libc::SCHED_FIFO, &param) != 0 {
            return Err(std::io::Error::last_os_error());
        }
    }
    Ok(())
}

/// Locks the process image into physical memory so that a page fault cannot
/// delay a transition mid-run.
fn lock_memory() -> std::io::Result<()> {
    unsafe {
        if libc::mlockall(libc::MCL_CURRENT | libc::MCL_FUTURE) != 0 {
            return Err(std::io::Error::last_os_error());
        }
    }
    Ok(())
}

/// Reduces the kernel timer slack to a single nanosecond. Real-time threads
/// already run with no slack, but setting it explicitly keeps the timing
/// honest if the SCHED_FIFO promotion is refused.
fn tighten_timer_slack() {
    unsafe {
        libc::prctl(PR_SET_TIMERSLACK, 1 as libc::c_ulong);
    }
}

/// Restricts the calling thread to a single CPU.
fn pin_to_cpu(cpu: usize) -> std::io::Result<()> {
    unsafe {
        let mut set: libc::cpu_set_t = std::mem::zeroed();
        libc::CPU_ZERO(&mut set);
        libc::CPU_SET(cpu, &mut set);

        if libc::sched_setaffinity(0, std::mem::size_of::<libc::cpu_set_t>(), &set) != 0 {
            return Err(std::io::Error::last_os_error());
        }
    }
    Ok(())
}

/// Touches every page of a stack-resident buffer so that the stack pages the
/// loop will use are already resident and dirty before timing begins.
fn prefault_stack() {
    const DEPTH: usize = 64 * 1024;
    let mut scratch = [0u8; DEPTH];

    for offset in (0..DEPTH).step_by(4096) {
        unsafe {
            std::ptr::write_volatile(&mut scratch[offset], 0);
        }
    }
}

fn main() {
    let args: Vec<String> = env::args().collect();

    if args.len() != 4 {
        eprintln!(
            "Usage: {} <GPIO PIN> <Flashes Per Second> <Time To Flash>",
            args[0]
        );
        process::exit(-1);
    }

    let pin: u8 = args[1].parse().expect("Invalid GPIO pin");
    let flashes_per_second: i64 = args[2].parse().expect("Invalid blink rate");
    let execution_time: i64 = args[3].parse().expect("Invalid duration");

    if flashes_per_second <= 0 || execution_time <= 0 {
        eprintln!("Flash rate and duration must both be greater than zero.");
        process::exit(-1);
    }

    // Period math mirrors the C++ version. Splitting the period into an on
    // time and an off time this way means the two halves always sum to the
    // full period, even when the period does not divide evenly. Halving the
    // period twice, as a naive implementation does, loses up to a microsecond
    // per cycle and shows up as a slow frequency error over a long run.
    let loop_count = execution_time * flashes_per_second;
    let period_us = 1_000_000 / flashes_per_second;
    let on_us = period_us / 2;
    let off_us = period_us - on_us;

    // Everything that allocates, opens a file, or writes to the terminal is
    // done here, before the thread goes real time. Once the loop starts, no
    // syscall other than the GPIO write and the sleep should occur.
    let gpio = Gpio::new().expect("Failed to access GPIO");
    let mut led: OutputPin = gpio.get(pin).expect("Invalid pin").into_output();

    // Suppress the reset-on-drop behavior so that the pin state at the end of
    // the run is the state this program last wrote, matching the C++ version.
    led.set_reset_on_drop(false);

    // The C++ version drives the pin low to light the LED and high to
    // extinguish it. Start in the extinguished state.
    led.set_high();

    println!(
        "Blinking GPIO {} at {} flashes/sec for {} seconds for {} flashes...",
        pin, flashes_per_second, execution_time, loop_count
    );
    let _ = std::io::stdout().flush();

    prefault_stack();

    if let Err(error) = lock_memory() {
        eprintln!("Warning: could not lock memory: {error}");
    }

    tighten_timer_slack();

    if let Some(cpu) = PIN_TO_CPU {
        if let Err(error) = pin_to_cpu(cpu) {
            eprintln!("Warning: could not set CPU affinity: {error}");
        }
    }

    if let Err(error) = set_realtime_priority() {
        eprintln!("Failed to set the scheduler: {error}");
        eprintln!("This program must be run as the super user.");
        process::exit(-1);
    }

    // The deadline advances by a fixed amount every half cycle, so any latency
    // absorbed on one transition is paid back on the next rather than being
    // carried forward.
    let mut deadline = now_monotonic();

    for _ in 0..loop_count {
        led.set_low();
        add_micros(&mut deadline, on_us);
        sleep_until(&deadline);

        led.set_high();
        add_micros(&mut deadline, off_us);
        sleep_until(&deadline);
    }

    led.set_high();
    println!("Done.");
}
